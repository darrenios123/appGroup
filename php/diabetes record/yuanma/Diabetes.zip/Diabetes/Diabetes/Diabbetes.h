//
//  Diabbetes.h
//  Diabetes
//
//  Created by apple on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#ifndef Diabbetes_h
#define Diabbetes_h

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define AppDefauftColor UIColorFromRGB(0x61e486)
#define DeaultLineColor UIColorFromRGB(0xdcdcdc)
//导航栏高度
#define HMNavigationBarHeight (([UIScreen mainScreen].bounds.size.width == 812.0) ? 88.0f : 64.0f)
#endif /* Diabbetes_h */
