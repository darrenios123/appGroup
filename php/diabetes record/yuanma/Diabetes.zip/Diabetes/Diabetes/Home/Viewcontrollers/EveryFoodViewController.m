//
//  EveryFoodViewController.m
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "EveryFoodViewController.h"
#import <VTMagic.h>
#import "FoodTableViewController.h"
@interface EveryFoodViewController ()<VTMagicViewDataSource,VTMagicViewDelegate>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong) NSArray *arr;
@end

@implementation EveryFoodViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.arr = @[@{@"title":@"Thin",
                   @"sections":@[@{@"title":@"Breakfast",
                                   @"foods":@[@{@"title":@"Whole wheat buns",
                                                @"subTitle":@"Whole wheat flour 50g"},
                                              @{@"title":@"Sesame catsup eggplant",
                                                @"subTitle":@"15g sesame paste and 100g eggplant"},
                                              @{@"title":@"Eggs",
                                                @"subTitle":@"ggs are a"},
                                              @{@"title":@"Milk",
                                                @"subTitle":@"200 grams of milk"}]},
                                 @{@"title":@"Lunch",
                                   @"foods":@[@{@"title":@"Red bean meal",
                                                @"subTitle":@"15 grams of red beans and 60 grams of rice"},
                                              @{@"title":@"Meat water bamboo",
                                                @"subTitle":@"30 grams of lean pork and 80 grams of water bamboo"},
                                              @{@"title":@"Garlic garden chrysanthemum",
                                                @"subTitle":@"Garden chrysanthemum 100 grams"},
                                              @{@"title":@"Mushroom soup with winter melon",
                                                @"subTitle":@"50 grams of winter melon and 10 grams of mushroom"}]},
                                 @{@"title":@"Dinner",
                                   @"foods":@[@{@"title":@"Chestnut rice",
                                                @"subTitle":@"Twenty-five grams of chestnuts and fifty grams of millet"},
                                              @{@"title":@"Tofu carp",
                                                @"subTitle":@"30 grams tofu, 80 grams carp"},
                                              @{@"title":@"Stir-fried mashed potatoes",
                                                @"subTitle":@"100 grams of potatoes"},
                                              @{@"title":@"Tomato mushroom soup",
                                                @"subTitle":@"50g tomato, 20g mushroom"}]},
                                 @{@"title":@"Fill in the morning",
                                   @"foods":@[@{@"title":@"Carambola",
                                                @"subTitle":@"Carambola 100 grams"}]}]
                   },
                 @{@"title":@"Obesity",
                   @"sections":@[@{@"title":@"Breakfast",
                                   @"foods":@[@{@"title":@"Sugarless yoghurt",
                                                @"subTitle":@"120 grams plain yogurt"},
                                              @{@"title":@"Baked buns",
                                                @"subTitle":@"Flour, 50 g"},
                                              @{@"title":@"Saute carrot slices",
                                                @"subTitle":@"150 g carrot"},
                                              @{@"title":@"Sausage",
                                                @"subTitle":@"Sausage, 20 g"}]},
                                 @{@"title":@"Lunch",
                                   @"foods":@[@{@"title":@"Two rice",
                                                @"subTitle":@"35 grams of rice, 15 grams of millet"},
                                              @{@"title":@"Onions Fried meat",
                                                @"subTitle":@" grams of Onions and 50 grams of lean meat"},
                                              @{@"title":@"Stir-fried pea sprouts",
                                                @"subTitle":@"150g pea seedling"}
                                              ]},
                                 @{@"title":@"Dinner",
                                   @"foods":@[@{@"title":@"Dumplings",
                                                @"subTitle":@"50g flour, 50g lean pork, 25g shallots"},
                                              @{@"title":@"Bai luobo porridge",
                                                @"subTitle":@"100 grams of rice and 50 grams of white radish"}
                                              ]},
                                 @{@"title":@"Fill in the morning",
                                   @"foods":@[@{@"title":@"Tomato",
                                                @"subTitle":@"100 g tomatoes"}]}]
                   },
                 @{@"title":@"Pregnancy",
                   @"sections":@[@{@"title":@"Breakfast",
                                   @"foods":@[@{@"title":@"Soybean curd",
                                                @"subTitle":@"200 grams of beancurd"},
                                              @{@"title":@"Rolls",
                                                @"subTitle":@"75 g flour"},
                                              @{@"title":@"Tea eggs",
                                                @"subTitle":@"Eggs are a"},
                                              @{@"title":@"Onion and carrot",
                                                @"subTitle":@"50 grams of Onions and 60 grams of carrots"}]},
                                 @{@"title":@"Lunch",
                                   @"foods":@[@{@"title":@"Peas, rice",
                                                @"subTitle":@"25 grams of peas, 75 grams of rice"},
                                              @{@"title":@"Stir-fry the rapeseed",
                                                @"subTitle":@"300 grams of rapeseed"},
                                              @{@"title":@"Braise in soy sauce flat fish",
                                                @"subTitle":@"100 g flat fish"},
                                              @{@"title":@"Cantaloup",
                                                @"subTitle":@"Cantaloup 150 grams"}]},
                                 @{@"title":@"Dinner",
                                   @"foods":@[@{@"title":@"Steamed bread",
                                                @"subTitle":@"100 g flour"},
                                              @{@"title":@"Eggplant",
                                                @"subTitle":@"Eggplant is 150 grams"},
                                              @{@"title":@"Chicken wire mixed with cauliflower",
                                                @"subTitle":@"75 grams of chicken breast and 150 grams of cauliflower"}
                                              ]},
                                 @{@"title":@"Fill in the morning",
                                   @"foods":@[@{@"title":@"The oranges",
                                                @"subTitle":@"100 g oranges"}]}]
                   },
                 @{@"title":@"The elderly",
                   @"sections":@[@{@"title":@"Breakfast",
                                   @"foods":@[@{@"title":@"Vegetable noodles",
                                                @"subTitle":@"75 grams of noodles, 50 grams of lean meat, 100 grams of spinach and 3 grams of seaweed"}
                                              ]},
                                 @{@"title":@"Lunch",
                                   @"foods":@[@{@"title":@"Steamed bread",
                                                @"subTitle":@"100 g flour"},
                                              @{@"title":@"Onion chicken nuggets",
                                                @"subTitle":@"25 grams of Onions and 100 grams of eggs"},
                                              @{@"title":@"Stir-fry leeks with green bean sprouts",
                                                @"subTitle":@"Green bean sprout 150 grams, leek 50 grams"}]},
                                 @{@"title":@"Dinner",
                                   @"foods":@[@{@"title":@"Kidney bean meal",
                                                @"subTitle":@"Twenty-five grams of kidney beans and fifty grams of rice"},
                                              @{@"title":@"Garlic moss fry meat",
                                                @"subTitle":@"100g garlic moss, 25g lean pork"},
                                              @{@"title":@"Scrambled eggs with tomatoes",
                                                @"subTitle":@"150 grams of tomatoes and 1 egg"}]},
                                 @{@"title":@"Fill in the morning",
                                   @"foods":@[@{@"title":@"Pears",
                                                @"subTitle":@"100 grams of pears"}]}]
                   },
                 @{@"title":@"Children",
                   @"sections":@[@{@"title":@"Breakfast",
                                   @"foods":@[@{@"title":@"Milk",
                                                @"subTitle":@"250 grams of milk"},
                                              @{@"title":@"Whole wheat bread",
                                                @"subTitle":@"50g whole wheat bread"},
                                              @{@"title":@"Sausage",
                                                @"subTitle":@"Sausage 25 g"},
                                              @{@"title":@"Steamed sweet potatoes",
                                                @"subTitle":@"Steamed sweet potato 50g"}]},
                                 @{@"title":@"Lunch",
                                   @"foods":@[@{@"title":@"Mung bean meal",
                                                @"subTitle":@"Mung bean 25 grams, rice 50 grams"},
                                              @{@"title":@"Potato beef",
                                                @"subTitle":@"100g potatoes and 75g beef"},
                                              @{@"title":@"Broccoli shrimp",
                                                @"subTitle":@"200 grams broccoli, 5 grams scary"}]},
                                 @{@"title":@"晚餐",
                                   @"foods":@[@{@"title":@"Buckwheat noodles",
                                                @"subTitle":@"50 grams of buckwheat flour"},
                                              @{@"title":@"Minced meat in tomato ding",
                                                @"subTitle":@"Pork lean meat 50g, eggplant 100g, pepper 50g"},
                                              @{@"title":@"Tomato and egg soup",
                                                @"subTitle":@"100g tomato and 1 egg"}]},
                                 @{@"title":@"Fill in the morning",
                                   @"foods":@[@{@"title":@"Watermelon with skin",
                                                @"subTitle":@"The watermelon has 100g skin"}]}]
                   }];
    [self addChildViewController:self.magicController];
    [self.view addSubview:_magicController.view];
    _magicController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-HMNavigationBarHeight);
    
    [_magicController.magicView reloadData];
}
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = AppDefauftColor;
        _magicController.magicView.layoutStyle = VTLayoutStyleDivide;
        _magicController.magicView.switchStyle = VTSwitchStyleDefault;
        _magicController.magicView.navigationHeight = 40.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
    }
    return _magicController;
}

#pragma mark - VTMagicViewDataSource
- (NSArray<__kindof NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    NSMutableArray *arr = [NSMutableArray arrayWithCapacity:0];
    for (NSDictionary *dic in self.arr) {
        [arr addObject:dic[@"title"]];
    }
    return arr;
}
- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"itemIdentifier";
    UIButton *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (!menuItem) {
        menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [menuItem setTitleColor:AppDefauftColor forState:UIControlStateSelected];
        menuItem.titleLabel.font = [UIFont systemFontOfSize:14];
    }
    return menuItem;
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex; {
    static NSString *gridId = @"grid.identifier";
    FoodTableViewController *gridViewController = [magicView dequeueReusablePageWithIdentifier:gridId];
    if (!gridViewController) {
        gridViewController = [[FoodTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
    }
    
    gridViewController.sections = self.arr[pageIndex][@"sections"];
    [gridViewController.tableView reloadData];
    return gridViewController;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
