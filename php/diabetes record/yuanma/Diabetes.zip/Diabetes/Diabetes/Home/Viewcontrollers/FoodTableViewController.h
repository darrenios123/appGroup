//
//  FoodTableViewController.h
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodTableViewController : UITableViewController
@property (nonatomic, strong) NSArray *sections;
@end
