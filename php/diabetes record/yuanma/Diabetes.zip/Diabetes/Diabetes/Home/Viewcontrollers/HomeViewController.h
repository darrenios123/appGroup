//
//  HomeViewController.h
//  Diabetes
//
//  Created by haohao on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end
