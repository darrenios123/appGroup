//
//  HomeViewController.m
//  Diabetes
//
//  Created by haohao on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "HomeViewController.h"
#import "NextViewController.h"
@interface HomeViewController ()
@property (weak, nonatomic) IBOutlet UIView *topView;
@property (weak, nonatomic) IBOutlet UIImageView *addView;
@property (weak, nonatomic) IBOutlet UILabel *currentTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *currentValueLabel;
@property (weak, nonatomic) IBOutlet UIImageView *placeHeaderView;
@property (weak, nonatomic) IBOutlet UIButton *qiandaoBtn;
@property (weak, nonatomic) IBOutlet UIView *centerView;
@property (weak, nonatomic) IBOutlet UIButton *celiangBtn;
@property (weak, nonatomic) IBOutlet UIButton *foodBtn;
@property (weak, nonatomic) IBOutlet UIButton *recordBtn;
@property (weak, nonatomic) IBOutlet UIButton *serviceBtn;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet UIView *detailView;
@property (weak, nonatomic) IBOutlet UIScrollView *myScro;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = AppDefauftColor;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.myScro.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 200+85+110+40+90+300);
    self.addView.layer.cornerRadius = 60;
    self.addView.layer.masksToBounds = YES;
    
    self.currentTitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
    self.currentValueLabel.text = [User currentValue].length ? [User currentValue] : @"0.0";
    
    self.qiandaoBtn.backgroundColor = AppDefauftColor;
    self.qiandaoBtn.layer.cornerRadius = 15;
    self.qiandaoBtn.layer.masksToBounds = YES;
    
    self.centerView.backgroundColor = AppDefauftColor;
    self.celiangBtn.backgroundColor = [UIColor whiteColor];
    self.celiangBtn.layer.cornerRadius = 20;
    self.celiangBtn.layer.masksToBounds = YES;
    
    self.foodBtn.layer.cornerRadius = 20;
    self.foodBtn.layer.masksToBounds = YES;
    
    self.recordBtn.layer.cornerRadius = 20;
    self.recordBtn.layer.masksToBounds = YES;
    
    self.serviceBtn.layer.cornerRadius = 20;
    self.serviceBtn.layer.masksToBounds = YES;
    
    self.lineView.backgroundColor = AppDefauftColor;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectDetail:)];
    tap.numberOfTapsRequired = 1;
    [self.detailView addGestureRecognizer:tap];
    
    
}
-(void)viewDidLayoutSubviews
{
     self.myScro.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 200+85+110+40+90+300);
}

- (IBAction)qiandaoBtn:(id)sender {
    [self showHudWithMessage:@"In the sign in..."];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self showHudWithMessage:@"Sign in successfully" forInterval:1];
    });
}
- (IBAction)addBtn:(id)sender {
        UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        NextViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"NextViewController"];
        vc.saveBlock = ^(NSString *value) {
            self.currentValueLabel.text = value;
        };
        [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)detailBtn:(id)sender {
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)selectDetail:(UITapGestureRecognizer *)sender {
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)celiangBtn:(id)sender {
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NextViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"NextViewController"];
    vc.saveBlock = ^(NSString *value) {
        self.currentValueLabel.text = value;
    };
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)loginBtn:(id)sender {
//    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
//    LoginViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
//
//    //一顿设置
//
//    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
