//
//  NextViewController.h
//  Diabetes
//
//  Created by haohao on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "BaseViewController.h"
typedef void(^SaveBlock)(NSString *value);
@interface NextViewController : BaseViewController
@property (nonatomic, copy) SaveBlock saveBlock;
@end
