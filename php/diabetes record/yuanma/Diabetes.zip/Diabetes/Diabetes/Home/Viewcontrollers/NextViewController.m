//
//  NextViewController.m
//  Diabetes
//
//  Created by haohao on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "NextViewController.h"
#import "TTScrollRulerView.h"
@interface NextViewController ()<UIPickerViewDelegate,UIPickerViewDataSource,rulerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIPickerView *statusPickview;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *statusViewWith;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pickTopheight;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;
@property (weak, nonatomic) IBOutlet TTScrollRulerView *valueRuleview;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;
@property (nonatomic, strong) NSArray *titles;
@end

@implementation NextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm";
    self.timeLabel.text = [formatter stringFromDate:[NSDate date]];
    
    self.statusLabel.textColor = AppDefauftColor;
    self.statusLabel.text = @"Empty stomach";
    
    self.titles = @[@"Empty stomach",@"After breakfast",@"Before lunch",@"After lunch",@"Before dinner",@"After dinner",@"Before going to bed",@"Random"];
    
    self.statusPickview.backgroundColor = AppDefauftColor;
    self.statusPickview.delegate = self;
    self.statusPickview.dataSource = self;
    self.statusPickview.transform = CGAffineTransformMakeRotation(M_PI*3/2.);
    self.statusViewWith.constant = [UIScreen mainScreen].bounds.size.width;
    self.pickTopheight.constant = -120;
    
    self.valueLabel.textColor = AppDefauftColor;
    
    self.valueRuleview.backgroundColor = AppDefauftColor;
    self.valueRuleview.rulerDelegate = self;
    self.valueRuleview.rulerDirection = RulerDirectionHorizontal;
    self.valueRuleview.pointerBackgroundColor = [UIColor blueColor];
//    self.valueRuleview.rulerFace = RulerFace_down_right;
    self.valueRuleview.lockMax = 330;
    self.valueRuleview.lockMin = 0;
    self.valueRuleview.lockDefault = 70;
    self.valueRuleview.unitValue = 1;
    //    self.heightView.rulerBackgroundColor = [UIColor clearColor];
    //    [self.heightView customRulerWithLineColor:customColorMake(255, 255, 255) NumColor:[UIColor whiteColor] scrollEnable:YES];
    //在执行此方法前，可先设定参数：最小值，最大值，横向，纵向等等  ------若不设定，则按照默认值绘制
    [self.valueRuleview classicRuler];
    
    
    self.saveBtn.layer.cornerRadius = 20;
    self.saveBtn.layer.masksToBounds = YES;
    self.saveBtn.backgroundColor = AppDefauftColor;
//    self.saveBtn.layer.borderWidth = 1;
//    self.saveBtn.layer.borderColor = AppDefauftColor.CGColor;
    [self.saveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

#pragma mark - UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return 8;
}
#pragma mark - UIPickerViewDelegate
//- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
//    return 100;
//}
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 180;
}
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view {
    for(UIView *singleLine in pickerView.subviews)
    {
        if (singleLine.frame.size.height < 1)
        {
            singleLine.backgroundColor = [UIColor clearColor];
        }
    }
    UILabel *label = [[UILabel alloc] init];
    label.font = [UIFont systemFontOfSize:22];
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.text = self.titles[row];
    label.transform = CGAffineTransformMakeRotation(M_PI_2);
    return label;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    self.statusLabel.text = self.titles[row];
}
- (IBAction)saveBtn:(id)sender {
    [self showHudWithMessage:@"In the save..."];
    [User setCurrentValue:self.valueLabel.text];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self showHudWithMessage:@"Save success" forInterval:1 completion:^{
            if (self.saveBlock) {
                self.saveBlock(self.valueLabel.text);
            }
            [self.navigationController popViewControllerAnimated:YES];
        }];
    });
}

#pragma mark - rulerDelegate
- (void)rulerWith:(NSInteger)days {
    //即时打印出标尺滑动位置的数值
    self.valueLabel.text = [NSString stringWithFormat:@"%.1lf",days*0.1];
}

- (void)rulerRunEnd {
    NSLog(@"end");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
