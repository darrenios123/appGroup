//
//  ServiceViewController.h
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "BaseViewController.h"

@interface ServiceViewController : BaseViewController

@end
