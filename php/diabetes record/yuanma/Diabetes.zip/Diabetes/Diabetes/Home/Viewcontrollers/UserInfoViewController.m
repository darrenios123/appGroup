//
//  UserInfoViewController.m
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "UserInfoViewController.h"
#import "HeadTableViewCell.h"
#import "OtherInfoTableViewCell.h"
#import "LoginoutTableViewCell.h"
#import "LoginViewController.h"
#import "BaseNavigationViewController.h"
@interface UserInfoViewController ()<UITableViewDataSource,UITableViewDelegate,UIPickerViewDelegate,UIPickerViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tab;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pickBottomMargin;
@property (weak, nonatomic) IBOutlet UIButton *backView;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UIButton *sureBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIPickerView *myPickView;

@property (nonatomic, strong) NSString *nickName;
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *height;
@property (nonatomic, strong) NSString *weight;

@property (nonatomic, assign) int type;

@property (nonatomic, strong) NSMutableArray *genderArr;
@property (nonatomic, strong) NSMutableArray *heightArr;
@property (nonatomic, strong) NSMutableArray *weightArr;
@property (nonatomic, strong) NSMutableArray *ageArr;
@end

@implementation UserInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.backView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    [self.sureBtn setTitleColor:AppDefauftColor forState:UIControlStateNormal];
    self.backView.hidden = YES;
    if (@available(iOS 11.0,*)) {
        self.tab.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.myPickView.delegate = self;
    self.myPickView.dataSource = self;
    
    self.genderArr = [[NSMutableArray alloc] init];
    [self.genderArr addObjectsFromArray:@[@"Male",@"Female"]];
    self.heightArr = [[NSMutableArray alloc] init];
    self.weightArr = [[NSMutableArray alloc] init];
    self.ageArr = [[NSMutableArray alloc] init];
    for (int i = 1; i <=230; i++) {
        [self.heightArr addObject:[NSString stringWithFormat:@"%d",i]];
    }
    
    for (int i = 1; i < 300; i++) {
        [self.weightArr addObject:[NSString stringWithFormat:@"%d",i]];
    }
    
    for (int i = 1940; i < 2019; i++) {
        [self.ageArr addObject:[NSString stringWithFormat:@"%d",i]];
    }
}

#pragma mark -UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    } else if (section == 1) {
        return 2;
    } else if (section == 2) {
        return 4;
    }
    return 1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        HeadTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"head"];
        if (!cell) {
            cell = [[HeadTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"head"];
        }
        cell.titleLabel.text = @"Modify the picture";
        return cell;
    } else if (indexPath.section == 3) {
        LoginoutTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"login"];
        if (!cell) {
            cell = [[LoginoutTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"login"];
        }
        return cell;
    }
    OtherInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"other"];
    if (!cell) {
        cell = [[OtherInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"other"];
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.titleLabel.text = @"Nickname";
            cell.valueLabel.text = [User nickName];
        } else if (indexPath.row ==1) {
            cell.titleLabel.text = @"User name";
            cell.valueLabel.text = @"abc123456";
        }
    } else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            cell.titleLabel.text = @"Gender";
            cell.valueLabel.text = [User gender];
        } else if (indexPath.row == 1) {
            cell.titleLabel.text = @"Age";
            cell.valueLabel.text = [User age];
        } else if (indexPath.row == 2) {
            cell.titleLabel.text = @"Height";
            cell.valueLabel.text = [User height];
        } else if (indexPath.row == 3) {
            cell.titleLabel.text = @"Weight";
            cell.valueLabel.text = [User weight];
        }
    }
    if (indexPath.section == 1 && indexPath.row == 1) {
        cell.accessoryView.hidden = YES;
    } else {
        cell.accessoryView.hidden = NO;
    }
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 50;
    }
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 10;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
//        UIAlertController *altervc = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
//        [altervc addAction:[UIAlertAction actionWithTitle:@"Taking pictures" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//            
//        }]];
//        [altervc addAction:[UIAlertAction actionWithTitle:@"Photo album" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//            
//        }]];
//        [altervc addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//            
//        }]];
//        [self presentViewController:altervc animated:YES completion:nil];
    } else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            UIAlertController *altervc = [UIAlertController alertControllerWithTitle:@"Nickname" message:nil preferredStyle:UIAlertControllerStyleAlert];
            [altervc addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
                
            }];
            [altervc addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
            }]];
            [altervc addAction:[UIAlertAction actionWithTitle:@"Sure" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                UITextField *textField = altervc.textFields.firstObject;
                if (textField && textField.text.length == 0) {
                    [self showHudWithMessage:@"Please edit nickname" forInterval:0];
                    return;
                }
                [self showProgressHudWithMessage:nil progressModel:MBProgressHUDModeIndeterminate];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self dismissHud];
                    [User setNickName:textField.text];
                    [self showHudWithMessage:@"Save success" forInterval:1];
                    self.nickName = textField.text;
                    [self.tab reloadData];
                });
            }]];
            [self presentViewController:altervc animated:YES completion:nil];
        }
    } else if(indexPath.section == 2) {
        if (indexPath.row == 0) {
//            if (self.bottomView.frame.origin.y != [UIScreen mainScreen].bounds.size.height) {
//                return;
//            }
            self.type = 1;

            self.backView.hidden = NO;
            [self.bottomView layoutIfNeeded];
            [UIView animateWithDuration:0.5 animations:^{
            
            CGRect frame = self.bottomView.frame;
            frame.origin.y = [UIScreen mainScreen].bounds.size.height-HMNavigationBarHeight-180;
            self.bottomView.frame = frame;
            
            } completion:^(BOOL finished) {
                
            }];
            
            
        } else if (indexPath.row == 1) {
//            if (self.bottomView.frame.origin.y != [UIScreen mainScreen].bounds.size.height) {
//                return;
//            }
            self.type = 4;
            self.backView.hidden = NO;
            [self.bottomView layoutIfNeeded];
            [UIView animateWithDuration:0.5 animations:^{
                
                CGRect frame = self.bottomView.frame;
                frame.origin.y = [UIScreen mainScreen].bounds.size.height-HMNavigationBarHeight-180;
                self.bottomView.frame = frame;
                
            }];
        } else if (indexPath.row == 2) {
//            if (self.bottomView.frame.origin.y != [UIScreen mainScreen].bounds.size.height) {
//                return;
//            }
            self.type = 2;
            self.backView.hidden = NO;
            [self.bottomView layoutIfNeeded];
            [UIView animateWithDuration:0.5 animations:^{
                
                CGRect frame = self.bottomView.frame;
                frame.origin.y = [UIScreen mainScreen].bounds.size.height-HMNavigationBarHeight-180;
                self.bottomView.frame = frame;
                
            }];
        } else if (indexPath.row ==3) {
//            if (self.bottomView.frame.origin.y != [UIScreen mainScreen].bounds.size.height) {
//                return;
//            }
            self.type = 3;
            self.backView.hidden = NO;
            [self.bottomView layoutIfNeeded];
            [UIView animateWithDuration:0.5 animations:^{
                
                CGRect frame = self.bottomView.frame;
                frame.origin.y = [UIScreen mainScreen].bounds.size.height-HMNavigationBarHeight-180;
                self.bottomView.frame = frame;
                
            }];
        }
        [self.myPickView reloadComponent:0];
//        [self.myPickView selectedRowInComponent:0];
    } else if(indexPath.section == 3) {
        UIAlertController *altervc = [UIAlertController alertControllerWithTitle:@"Prompt" message:@"Log out？" preferredStyle:UIAlertControllerStyleAlert];
        [altervc addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
        [altervc addAction:[UIAlertAction actionWithTitle:@"Sure" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
            LoginViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
            [UIApplication sharedApplication].delegate.window.rootViewController = [[BaseNavigationViewController alloc] initWithRootViewController:vc];
            //
        }]];
        [self presentViewController:altervc animated:YES completion:nil];
    }
    
    
}
- (IBAction)cancleBtn:(id)sender {
    
    [UIView animateWithDuration:0.5 animations:^{
        
        CGRect frame = self.bottomView.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height-HMNavigationBarHeight;
        self.bottomView.frame = frame;
        
    } completion:^(BOOL finished) {
        self.backView.hidden = YES;
    }];
}
#pragma mark - UIPickerViewDataSource
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (self.type == 1) {
        return self.genderArr.count;
    } else if (self.type == 2) {
        return self.heightArr.count;
    } else if (self.type == 3) {
        return self.weightArr.count;
    } else if (self.type == 4) {
        return self.ageArr.count;
    }
    return 0;
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (self.type == 1) {
        return self.genderArr[row];
    } else if (self.type == 2) {
        return self.heightArr[row];
    } else if (self.type == 3) {
        return self.weightArr[row];
    } else if (self.type == 4) {
        return self.ageArr[row];
    }
    return nil;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 40;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (self.type == 1) {
        [User setGender:self.genderArr[row]];
    } else if (self.type == 2) {
        [User setHeight:[NSString stringWithFormat:@"%@cm",self.heightArr[row]]];
    } else if (self.type == 3) {
        [User setWeight:[NSString stringWithFormat:@"%@kg",self.weightArr[row]]];
    } else if (self.type == 4) {
        NSString *te = self.ageArr[row];
        [User setAge:[NSString stringWithFormat:@"%ldyears old",2018-te.integerValue]];
    }
}
#pragma mark - Action

- (IBAction)cancancleBtn:(id)sender {
    [UIView animateWithDuration:0.5 animations:^{
        
        CGRect frame = self.bottomView.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.bottomView.frame = frame;
        
    } completion:^(BOOL finished) {
        self.backView.hidden = YES;
    }];
}

- (IBAction)sureBtn:(id)sender {
    [UIView animateWithDuration:0.5 animations:^{
        
        CGRect frame = self.bottomView.frame;
        frame.origin.y = [UIScreen mainScreen].bounds.size.height;
        self.bottomView.frame = frame;
        
    } completion:^(BOOL finished) {
        self.backView.hidden = YES;
        [self.tab reloadData];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
