//
//  FoodsTableViewCell.m
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "FoodsTableViewCell.h"

@implementation FoodsTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self awakeFromNib];
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
    self.topLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, [UIScreen mainScreen].bounds.size.width-30, 17)];
    self.topLabel.font = [UIFont systemFontOfSize:17];
    [self.contentView addSubview:self.topLabel];
    
    self.subLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 25, [UIScreen mainScreen].bounds.size.width-30, 60)];
    self.subLabel.font = [UIFont systemFontOfSize:14];
    self.subLabel.textColor = [UIColor lightGrayColor];
    self.subLabel.numberOfLines = 0;
    [self.contentView addSubview:self.subLabel];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
