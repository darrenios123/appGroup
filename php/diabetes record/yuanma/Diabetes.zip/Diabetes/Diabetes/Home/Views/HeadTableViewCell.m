//
//  HeadTableViewCell.m
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "HeadTableViewCell.h"

@implementation HeadTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.headView.backgroundColor = [AppDefauftColor colorWithAlphaComponent:0.5];
    self.headView.layer.cornerRadius = 15;
    self.headView.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
