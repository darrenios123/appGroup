//
//  OtherInfoTableViewCell.m
//  Diabetes
//
//  Created by apple on 2018/6/3.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "OtherInfoTableViewCell.h"

@implementation OtherInfoTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.lineView.backgroundColor = DeaultLineColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
