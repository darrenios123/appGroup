//
//  UIViewController+Alert.h
//  PayViewTest
//
//  Created by chenao on 2017/9/19.
//  Copyright © 2017年 hm. All rights reserved.
//

#import <UIKit/UIKit.h>
//Alert必须引入的三方弹框
#import <MBProgressHUD.h>

@interface UIViewController (Alert)

/**
 弹出系统AlertSheet
 
 @param title Title
 @param subTitle subTitle
 @param actionTitleArray 响应按钮字符数组
 @param actionCompletion 按钮响应标签和字符位置对应
 @param alertCompletion 弹出这个视图后的处理
 */
- (UIAlertController *)hm_showActionSheetWithTitle:(NSString *)title
                                          subTitle:(NSString *)subTitle
                                  actionTitleArray:(NSArray *)actionTitleArray
                                  actionCompletion:(void (^)(NSInteger index))actionCompletion
                                   alertCompletion:(void (^)(void))alertCompletion;
/**
 弹出系统提示框

 @param title Title
 @param subTitle subTitle
 @param actionTitleArray 响应按钮字符数组
 @param actionCompletion 按钮响应标签和字符位置对应
 @param alertCompletion 弹出这个视图后的处理
 */
- (UIAlertController *)hm_showAlertWithTitle:(NSString *)title
                      subTitle:(NSString *)subTitle
              actionTitleArray:(NSArray *)actionTitleArray
              actionCompletion:(void (^)(NSInteger index))actionCompletion
               alertCompletion:(void (^)(void))alertCompletion;

/**
 弹出UIAlertViewController提示框
 
 @param title 标题
 @param subTitle 内容
 @param sureAction 确定回调
 */
- (void)hm_showAlertWithTitle:(NSString *)title
                      subTitle:(NSString *)subTitle
                    sureAction:(void(^)())sureAction;
/**
 弹出UIAlertViewController提示框
 
 @param title 标题
 @param subTitle 内容
 @param cancelTitle 取消Title
 @param sureTile 确定Title
 @param sureAction 确定回调
 */
- (void)hm_showAlertWithTitle:(NSString *)title
                      subTitle:(NSString *)subTitle
                   cancelTitle:(NSString *)cancelTitle
                     sureTitle:(NSString *)sureTile
                    sureAction:(void(^)())sureAction;

//弹框分类：文字类型, 进度类型


/**
 文字类型（手动隐藏）
 
 @param message 文字信息
 */
- (void)showHudWithMessage:(NSString *)message;

- (void)showHudWithMessageWithDefaultInterval:(NSString *)message;

/**
 显示提示语在主屏幕上
 
 @param toast 提示文本
 */
+ (void)hm_showToastOnWindow:(NSString *)toast;

/**
 文字类型（自动隐藏）

 @param message 文字信息
 @param timeInSeconds 几秒后消失  传0默认1秒
 */
- (void)showHudWithMessage:(NSString *)message forInterval:(NSTimeInterval)timeInSeconds;


/**
 文字类型（自动隐藏） + 回调方法

 @param message 文字信息
 @param timeInSeconds 几秒后消失  传0默认1秒
 @param completionBlock 回调
 */
- (void)showHudWithMessage:(NSString *)message forInterval:(NSTimeInterval)timeInSeconds completion:(void(^)(void))completionBlock;






/**
 进度类型（一般用于图片上传等）

 @param message 进度值
 @param model 进度类型
 MBProgressHUDModeIndeterminate  常规菊花类
 MBProgressHUDModeDeterminate 圆饼
 MBProgressHUDModeDeterminateHorizontalBar 水平进度条
 MBProgressHUDModeAnnularDeterminate 环形
 */
- (void)showProgressHudWithMessage:(NSString *)message progressModel:(MBProgressHUDMode)model;




//隐藏
- (void)dismissHud;

@end
