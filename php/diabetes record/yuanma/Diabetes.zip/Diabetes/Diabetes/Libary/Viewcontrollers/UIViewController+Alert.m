//
//  UIViewController+Alert.m
//  PayViewTest
//
//  Created by chenao on 2017/9/19.
//  Copyright © 2017年 hm. All rights reserved.
//

#import "UIViewController+Alert.h"

#define HudViewTag  801


#define kShortInterval 1
#define kVeryShortInterval 0.5
@implementation UIViewController (Alert)
- (UIAlertController *)hm_showActionSheetWithTitle:(NSString *)title
                                          subTitle:(NSString *)subTitle
                                  actionTitleArray:(NSArray *)actionTitleArray
                                  actionCompletion:(void (^)(NSInteger))actionCompletion
                                   alertCompletion:(void (^)(void))alertCompletion {
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:title message:subTitle preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionTitleArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIAlertAction * alertAction = [UIAlertAction actionWithTitle:obj style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (actionCompletion) {
                actionCompletion(idx);
            }else {
                [alertVC dismissViewControllerAnimated:YES completion:nil];
            }
        }];
        [alertVC addAction:alertAction];
    }];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertVC addAction:action];
    [self presentViewController:alertVC animated:YES completion:alertCompletion];
    return alertVC;
}
- (UIAlertController *)hm_showAlertWithTitle:(NSString *)title
                      subTitle:(NSString *)subTitle
              actionTitleArray:(NSArray *)actionTitleArray
              actionCompletion:(void (^)(NSInteger index))actionCompletion
               alertCompletion:(void (^)(void))alertCompletion {
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:title message:subTitle preferredStyle:UIAlertControllerStyleAlert];
    
    [actionTitleArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIAlertAction * alertAction = [UIAlertAction actionWithTitle:obj style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (actionCompletion) actionCompletion(idx);
        }];
        [alertVC addAction:alertAction];
    }];

    if (self.presentedViewController) {
        return (UIAlertController *)self.presentedViewController;
    }
    [self presentViewController:alertVC animated:YES completion:alertCompletion];
    return alertVC;
}

- (void)hm_showAlertWithTitle:(NSString *)title
                      subTitle:(NSString *)subTitle
                    sureAction:(void(^)())sureAction {
    [self hm_showAlertWithTitle:title
                        subTitle:subTitle
                actionTitleArray:@[@"取消",@"确认"]
                actionCompletion:^(NSInteger index) {
                    if (index == 1) {
                        if (sureAction) sureAction();
                    }
                } alertCompletion:nil];
}

- (void)hm_showAlertWithTitle:(NSString *)title
                      subTitle:(NSString *)subTitle
                   cancelTitle:(NSString *)cancelTitle
                     sureTitle:(NSString *)sureTile
                    sureAction:(void(^)())sureAction {
    NSMutableArray * actionTitle = [NSMutableArray array];
    [actionTitle addObject:cancelTitle];
    [actionTitle addObject:sureTile];
    [self hm_showAlertWithTitle:title
                        subTitle:subTitle
                actionTitleArray:actionTitle
                actionCompletion:^(NSInteger index) {
                    if (index == actionTitle.count - 1) {
                        if (sureAction) sureAction();
                    }
                } alertCompletion:nil];
}

#pragma mark - 柴高

- (void)showHudWithMessage:(NSString *)message {
    [self updateHudWithMessage:message mode:MBProgressHUDModeText];
}

- (void)showHudWithMessageWithDefaultInterval:(NSString *)message{
    [UIViewController hm_showToastOnWindow:message];
//    [self showHudWithMessage:message forInterval:2 completion:nil];
}

- (void)showHudWithMessage:(NSString *)message forInterval:(NSTimeInterval)timeInSeconds {
    [self showHudWithMessage:message forInterval:timeInSeconds completion:nil];
}

- (void)showHudWithMessage:(NSString *)message forInterval:(NSTimeInterval)timeInSeconds completion:(void(^)(void))completionBlock {
    if (timeInSeconds <= 0) {
        timeInSeconds = kShortInterval;
    }
    
    [self updateHudWithMessage:message mode:MBProgressHUDModeText];
    [self dismissHudAfterInterval:timeInSeconds completion:completionBlock];
}

- (void)showProgressHudWithMessage:(NSString *)message progressModel:(MBProgressHUDMode)model {
     [self updateHudWithMessage:message mode:model]; 
}

- (void)updateHudWithMessage:(NSString *)message mode:(MBProgressHUDMode)mode {
    MBProgressHUD *hud = [MBProgressHUD HUDForView:self.view];
    if (!message) {
        message = @"";
    }else if (![message isKindOfClass:[NSString class]]){
        message = message.description;
    }
    if (!hud) {
        hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.removeFromSuperViewOnHide = YES;
        hud.bezelView.backgroundColor = [UIColor darkGrayColor];
        
//        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTap:)];
//        [hud addGestureRecognizer:singleTap];
    }
    
    if (mode == MBProgressHUDModeText) {
        hud.detailsLabel.text = message;
        hud.detailsLabel.textColor = [UIColor whiteColor];
        hud.label.text = nil;
        hud.detailsLabel.font = [UIFont systemFontOfSize:16];
        hud.mode = mode;
    }else{
        hud.label.text = message;
        hud.mode = mode;
    }
    
    
}

- (void) dismissHud {
    
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

- (void)dismissHudAfterInterval:(NSTimeInterval)timeInSeconds {
    [self dismissHudAfterInterval:timeInSeconds completion:nil];
}

- (void)dismissHudAfterInterval:(NSTimeInterval)timeInSeconds completion:(void(^)(void))completionBlock {
    if (timeInSeconds <= 0) {
        timeInSeconds = kVeryShortInterval;
    }
    
    MBProgressHUD *hud = [MBProgressHUD HUDForView:self.view];
    
    [hud hideAnimated:YES afterDelay:timeInSeconds];
    
    if (completionBlock) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(timeInSeconds * NSEC_PER_SEC)), dispatch_get_main_queue(), completionBlock);
    }
}

@end
