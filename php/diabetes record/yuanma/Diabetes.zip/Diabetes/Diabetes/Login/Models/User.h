//
//  User.h
//  Diabetes
//
//  Created by apple on 2018/6/6.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject
+ (void)setLogined:(NSNumber *)logined;
+ (NSNumber *)isLogined;

+ (void)setGender:(NSString *)gender;
+ (NSString *)gender;

+ (void)setAge:(NSString *)age;
+ (NSString *)age;

+ (void)setHeight:(NSString *)height;
+ (NSString *)height;

+ (void)setWeight:(NSString *)weight;
+ (NSString *)weight;


+ (void)setNickName:(NSString *)nickName;
+ (NSString *)nickName;

+ (void)setCurrentTime:(NSString *)currentTime;
+ (NSString *)currentTime;

+ (void)setCurrentValue:(NSString *)currentValue;
+ (NSString *)currentValue;
@end
