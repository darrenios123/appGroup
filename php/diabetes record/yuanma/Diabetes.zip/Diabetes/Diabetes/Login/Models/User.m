//
//  User.m
//  Diabetes
//
//  Created by apple on 2018/6/6.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "User.h"

@implementation User
+ (void)setLogined:(NSNumber *)logined {
    if (!logined) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:logined forKey:@"logined"];
    [def synchronize];
}
+ (NSNumber *)isLogined {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"logined"];
}

+ (void)setGender:(NSString *)gender {
    if (!gender) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:gender forKey:@"gender"];
    [def synchronize];
}
+ (NSString *)gender {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"gender"];
}

+ (void)setAge:(NSString *)age {
    if (!age) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:age forKey:@"age"];
    [def synchronize];
}
+ (NSString *)age {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"age"];
}

+ (void)setHeight:(NSString *)height {
    if (!height) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:height forKey:@"height"];
    [def synchronize];
}
+ (NSString *)height {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"height"];
}


+ (void)setWeight:(NSString *)weight {
    if (!weight) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:weight forKey:@"weight"];
    [def synchronize];
}
+ (NSString *)weight {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"weight"];
}


+ (void)setNickName:(NSString *)nickName {
    if (!nickName) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:nickName forKey:@"nickName"];
    [def synchronize];
}
+ (NSString *)nickName {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"nickName"];
}


+ (void)setCurrentTime:(NSString *)currentTime {
    if (!currentTime) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:currentTime forKey:@"currentTime"];
    [def synchronize];
}
+ (NSString *)currentTime {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"currentTime"];
}




+ (void)setCurrentValue:(NSString *)currentValue {
    if (!currentValue) {
        return;
    }
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:currentValue forKey:@"currentValue"];
    [def synchronize];
}
+ (NSString *)currentValue {
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"currentValue"];
}
@end
