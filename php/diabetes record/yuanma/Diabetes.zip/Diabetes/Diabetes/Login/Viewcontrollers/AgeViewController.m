//
//  AgeViewController.m
//  Diabetes
//
//  Created by apple on 2018/5/31.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "AgeViewController.h"
#import "FullTimeView.h"
#import "HeightViewController.h"
@interface AgeViewController ()<FinishPickView>
{
    NSDateFormatter *formatter;
}
@property (weak, nonatomic) IBOutlet FullTimeView *timePickview;
@property (weak, nonatomic) IBOutlet UILabel *ageLabel;
@property (weak, nonatomic) IBOutlet UIButton *nextBtn;

@end

@implementation AgeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = AppDefauftColor;
    formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy";
    self.timePickview.curDate=[[NSDate alloc] initWithTimeIntervalSince1970:0];
    self.timePickview.delegate=self;
    
    NSInteger now = [formatter stringFromDate:[NSDate date]].integerValue;
    NSInteger old = [formatter stringFromDate:[[NSDate alloc] initWithTimeIntervalSince1970:0]].integerValue;
    self.ageLabel.text = [NSString stringWithFormat:@"%ldyears old", now-old];
    
    self.nextBtn.layer.cornerRadius = 20;
    self.nextBtn.layer.masksToBounds = YES;
    self.nextBtn.layer.borderWidth = 1;
    self.nextBtn.layer.borderColor = [UIColor whiteColor].CGColor;
}
-(void)didFinishPickView:(NSDate *)date
{
    //获取的GMT时间，要想获得某个时区的时间，以下代码可以解决这个问题  详情：http://blog.csdn.net/chan1142131456/article/details/50237343
    
//    NSTimeZone *zone = [NSTimeZone systemTimeZone];
//    NSInteger interval = [zone secondsFromGMTForDate: date];
//    NSDate *localeDate = [date  dateByAddingTimeInterval: interval];
    formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy";
    NSInteger now = [formatter stringFromDate:[NSDate date]].integerValue;
    NSInteger old = [formatter stringFromDate:date].integerValue;
    self.ageLabel.text = [NSString stringWithFormat:@"%ldyears old", now-old];
}
- (IBAction)nextBtn:(id)sender {
    [User setAge:self.ageLabel.text];
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
    HeightViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"HeightViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
