//
//  GenderViewController.m
//  Diabetes
//
//  Created by apple on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "GenderViewController.h"
#import "AgeViewController.h"
@interface GenderViewController ()
@property (weak, nonatomic) IBOutlet UIButton *manBtn;
@property (weak, nonatomic) IBOutlet UIButton *womenBtn;

@end

@implementation GenderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = AppDefauftColor;
    self.manBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    self.manBtn.layer.borderWidth = 3;
    self.manBtn.layer.cornerRadius = 35;
    self.manBtn.layer.masksToBounds = YES;
    
    self.womenBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    self.womenBtn.layer.borderWidth = 3;
    self.womenBtn.layer.cornerRadius = 35;
    self.womenBtn.layer.masksToBounds = YES;
}
- (IBAction)manBtn:(id)sender {
    [User setGender:@"male"];
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
    AgeViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"AgeViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)womenBtn:(id)sender {
    [User setGender:@"female"];
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
    AgeViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"AgeViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
