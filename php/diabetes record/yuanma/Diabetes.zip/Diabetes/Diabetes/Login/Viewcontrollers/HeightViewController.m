//
//  HeightViewController.m
//  Diabetes
//
//  Created by apple on 2018/5/31.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "HeightViewController.h"
#import "TTScrollRulerView.h"
#import "WeightViewController.h"
@interface HeightViewController ()<rulerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *heightLabel;
@property (weak, nonatomic) IBOutlet UIButton *nextBtn;
@property (weak, nonatomic) IBOutlet TTScrollRulerView *heightView;

@end

@implementation HeightViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = AppDefauftColor;
    
    self.nextBtn.layer.cornerRadius = 20;
    self.nextBtn.layer.masksToBounds = YES;
    self.nextBtn.layer.borderWidth = 1;
    self.nextBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.heightView.rulerDelegate = self;
    self.heightView.rulerDirection = RulerDirectionVertical;
    self.heightView.pointerBackgroundColor = [UIColor blueColor];
    self.heightView.lockMax = 250;
    self.heightView.lockMin = 0;
    self.heightView.lockDefault = 100;
    self.heightView.unitValue = 1;
//    self.heightView.rulerBackgroundColor = [UIColor clearColor];
//    [self.heightView customRulerWithLineColor:customColorMake(255, 255, 255) NumColor:[UIColor whiteColor] scrollEnable:YES];
    //在执行此方法前，可先设定参数：最小值，最大值，横向，纵向等等  ------若不设定，则按照默认值绘制
    [self.heightView classicRuler];
    self.heightView.layer.borderWidth = 3;
    self.heightView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.heightView.layer.cornerRadius = 5;
    self.heightView.layer.masksToBounds = YES;
    self.heightLabel.text = @"100 cm";
}

#pragma mark - rulerDelegate
- (void)rulerWith:(NSInteger)days {
    //即时打印出标尺滑动位置的数值
    self.heightLabel.text = [NSString stringWithFormat:@"%ldcm",days];
}

- (void)rulerRunEnd {
    NSLog(@"end");
}
- (IBAction)nextBtn:(id)sender {
    [User setHeight:self.heightLabel.text];
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
    WeightViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"WeightViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
