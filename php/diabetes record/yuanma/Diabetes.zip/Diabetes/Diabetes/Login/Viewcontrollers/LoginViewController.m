//
//  LoginViewController.m
//  Diabetes
//
//  Created by haohao on 2018/5/30.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "LoginViewController.h"
#import "GenderViewController.h"
#import "HomeViewController.h"
#import "BaseNavigationViewController.h"
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *passwdTF;
@property (weak, nonatomic) IBOutlet UITextField *phoneTF;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = AppDefauftColor;
    self.phoneTF.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.passwdTF.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
    self.phoneTF.leftViewMode = self.passwdTF.leftViewMode = UITextFieldViewModeAlways;
    self.passwdTF.secureTextEntry = YES;
    self.loginBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    self.loginBtn.layer.borderWidth = 1;
    self.loginBtn.layer.cornerRadius = 20;
    self.loginBtn.layer.masksToBounds = YES;
}
- (IBAction)loginBtn:(id)sender {
    if (![self.phoneTF.text isEqualToString:@"abc123456"] || ![self.passwdTF.text isEqualToString:@"a123456"]) {
        [self showHudWithMessage:@"User name or password error" forInterval:0];
        return;
    }

    [self showProgressHudWithMessage:@"In the login" progressModel:MBProgressHUDModeIndeterminate];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self dismissHud];
        [self showHudWithMessage:@"Login successful" forInterval:0];
    });
    if ([User isLogined].boolValue) {
        UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        HomeViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [UIApplication sharedApplication].delegate.window.rootViewController = [[BaseNavigationViewController alloc] initWithRootViewController:vc];
    } else {
        UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
        GenderViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"GenderViewController"];
        
        //一顿设置
        
        [self.navigationController pushViewController:vc animated:YES];
         [User setLogined:[NSNumber numberWithBool:YES]];
    }
    
//    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
