//
//  WeightViewController.m
//  Diabetes
//
//  Created by apple on 2018/5/31.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import "WeightViewController.h"
#import "HomeViewController.h"
#import "BaseNavigationViewController.h"
@interface WeightViewController ()<UIPickerViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *nextBtn;
@property (weak, nonatomic) IBOutlet UIPickerView *weightPickview;
@property (weak, nonatomic) IBOutlet UILabel *weightLabel;

@end

@implementation WeightViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = AppDefauftColor;
    self.nextBtn.layer.cornerRadius = 20;
    self.nextBtn.layer.masksToBounds = YES;
    self.nextBtn.layer.borderWidth = 1;
    self.nextBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.weightPickview.delegate = self;
    self.weightPickview.tintColor = [UIColor whiteColor];
    self.weightPickview.layer.borderWidth = 3;
    self.weightPickview.layer.borderColor = [UIColor whiteColor].CGColor;
    self.weightPickview.layer.cornerRadius = 5;
    self.weightPickview.layer.masksToBounds = YES;
    
    [self.weightPickview selectRow:60 inComponent:0 animated:NO];
    self.weightLabel.text = @"60 kg";
    
}
- (IBAction)nextBtn:(id)sender {
    [User setWeight:self.weightLabel.text];
    UIStoryboard *destinationStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeViewController *vc = [destinationStoryboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [UIApplication sharedApplication].delegate.window.rootViewController = [[BaseNavigationViewController alloc] initWithRootViewController:vc];
//
//    //一顿设置
//
//    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIPickerViewDelegate
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return 300;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 40;
}

//- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
//    return [NSString stringWithFormat:@"%d",row+1];
//}

//- (nullable NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component {
//    NSAttributedString *att = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%ld",row+1] attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20 weight:UIFontWeightHeavy],NSForegroundColorAttributeName:[UIColor whiteColor]}];
//    return att;
//}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view {
    //设置分割线的颜色
    for(UIView *singleLine in pickerView.subviews)
    {
        if (singleLine.frame.size.height < 1)
        {
            CGRect frame = singleLine.frame;
            singleLine.backgroundColor = [UIColor whiteColor];
            frame.size.height = 1.5;
            singleLine.frame = frame;
        }
    }
    
    //设置文字的属性
    UILabel *genderLabel = [UILabel new];
    genderLabel.textAlignment = NSTextAlignmentCenter;
    genderLabel.text = [NSString stringWithFormat:@"%ld",row+1];//self.genderArray里边内容为@[@"男",@"女"]
    genderLabel.textColor = [UIColor whiteColor];
    genderLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightHeavy];
    
    return genderLabel;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    self.weightLabel.text = [NSString stringWithFormat:@"%ld kg",row+1];
}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
   
}


@end
