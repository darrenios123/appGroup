//
//  ArcSlider.m
//  Chaigao_PaySDK
//
//  Created by haohao on 2018/5/31.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "ArcSlider.h"
#define ToRad(deg)         ( (M_PI * (deg)) / 180.0 )
#define ToDeg(rad)        ( (180.0 * (rad)) / M_PI )
#define SQR(x)            ( (x) * (x) )
@interface ArcSlider()
{
    int angle;
}
@property (readonly, nonatomic) CGFloat radius;
@end
@implementation ArcSlider
- (void)initData {
    _maximumValue  = 100;
    _minimumValue = 0;
    _currentValue = 0;
    _lineWidth = 5;
    _handleWith = 10;
    _lineRadiusDisplacement = 0;
    _unfilledColor = [UIColor blackColor];
    _filledColor = [UIColor redColor];
    _handleColor = _filledColor;
    self.backgroundColor = [UIColor clearColor];
}
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initData];
        [self angleFromValue];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    //Draw the unfilled circle
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextAddArc(ctx, self.frame.size.width/2., self.radius+_handleWith/2., self.radius, M_PI*1, 2*M_PI, 0);
    [_unfilledColor setStroke];
    CGContextSetLineWidth(ctx, _lineWidth);
    CGContextSetLineCap(ctx, kCGLineCapButt);
    CGContextDrawPath(ctx, kCGPathStroke);
    
    //Draw the filled circle
    CGContextAddArc(ctx, self.frame.size.width/2, self.radius+_handleWith/2., self.radius, 1*M_PI, 1*M_PI+ToRad(angle), 0);
    [_filledColor setStroke];
    CGContextSetLineWidth(ctx, _lineWidth);
    CGContextSetLineCap(ctx, kCGLineCapButt);
    CGContextDrawPath(ctx, kCGPathStroke);
    
    
    //The draggable part
    [self drawHandle:ctx];
}

-(void) drawHandle:(CGContextRef)ctx{
    CGContextSaveGState(ctx);
    CGPoint handleCenter =  [self pointFromAngle:angle];
    [_handleColor set];
    if (angle>90) {
        CGContextFillEllipseInRect(ctx, CGRectMake(handleCenter.x-_handleWith/2., handleCenter.y-_handleWith/2., _handleWith, _handleWith));
    } else {
        CGContextFillEllipseInRect(ctx, CGRectMake(handleCenter.x-_handleWith/2., handleCenter.y-_handleWith/2., _handleWith, _handleWith));
    }
    
    CGContextRestoreGState(ctx);
}

-(CGPoint)pointFromAngle:(int)angleInt{
    CGPoint centerPoint;
    centerPoint = [self centerPoint];
    if (angleInt>90) {
        float h1 = self.radius * sin(ToRad(180-angleInt));
        float w1 = self.radius * cos(ToRad(180-angleInt));
        
        return CGPointMake(centerPoint.x+w1, centerPoint.y-h1);
    } else {
        float h1 = self.radius * sin(ToRad(angleInt));
        float w1 = self.radius * cos(ToRad(angleInt));
        
        return CGPointMake(centerPoint.x-w1, centerPoint.y-h1);
    }
    
}

- (CGFloat)radius {
    return self.frame.size.width/2.-_handleWith/2.;
}
- (float)angleFromValue {
    angle =(180.0f*_currentValue/_maximumValue);
    return angle;
}

#pragma mark - UIControl functions

-(BOOL) beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    [super beginTrackingWithTouch:touch withEvent:event];
    
    return YES;
}

-(BOOL) continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    [super continueTrackingWithTouch:touch withEvent:event];
    
    CGPoint lastPoint = [touch locationInView:self];
    if (lastPoint.y>self.frame.size.width/2.) {
        lastPoint.y = self.frame.size.width/2.;
    }
    [self moveHandle:lastPoint];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    
    return YES;
}

-(void)moveHandle:(CGPoint)point {
    CGPoint centerPoint;
    centerPoint = [self centerPoint];
    int currentAngle = floor(AngleFromNorth(centerPoint, point, NO));
    angle = currentAngle;
    _currentValue = [self valueFromAngle];
    [self setNeedsDisplay];
}
-(float) valueFromAngle {
    return (angle*(_maximumValue - _minimumValue))/180.0f;
}
- (CGPoint)centerPoint {
    return CGPointMake(self.frame.size.width/2, self.frame.size.width/2);
}

static inline float AngleFromNorth(CGPoint p1, CGPoint p2, BOOL flipped) {
    if (p2.x>p1.x) {
        float h1 = p1.y - p2.y;
        float w1 = p2.x - p1.x;
        return (180-ToDeg(atan(h1/w1)));
    } else {
        float h1 = p1.y - p2.y;
        float w1 = p1.x - p2.x;
        return ToDeg(atan(h1/w1));
    }
    
}

@end
